function bubbles(wrapperId, options) {
  const { containerWidth = 500, bubbleSize = 90, speed = 1, images = [] } = options;
  const D = 0.1 * bubbleSize;
  const SPACE_Y = 0.8 * bubbleSize;

  // get wrapper info
  const wrapper = document.querySelector(wrapperId);
  const height = wrapper.clientHeight;
  const width = Math.max(5.3 * bubbleSize + 2 * D, containerWidth);
  const minY = -bubbleSize;

  // create container
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.paddingLeft = '200px';

  container.style.height = '100%';
  container.style.width = '650px';
  container.style.overflow = 'hidden';
  wrapper.appendChild(container);

  // make random x
  function randomX(place) {
    return (place + Math.random()) * ((width - 2 * bubbleSize - 2 * D) / 3) + bubbleSize + D;
  }

  // init bubble
  function initBubble(bubble) {
    const { prevBubble } = bubble;
    if (!prevBubble) {
      bubble.place = 0;
      bubble.x = randomX(bubble.place);
      bubble.y = minY;
    } else {
      bubble.place = (prevBubble.place + 1) % 3;
      while (true) {
        bubble.x = randomX(bubble.place);
        if (Math.abs(prevBubble.x - bubble.x) >= bubbleSize) break;
      }
      bubble.y = prevBubble.y + SPACE_Y;
    }
    bubble.dx = 0;
    bubble.dy = (Math.random() - 0.5) * 2 * D;
    bubble.speedx = (Math.random() - 0.5) * 0.4;
    bubble.speedy = (Math.random() - 0.5) * 0.4;
  }

  // create bubbles
  let prevBubble;
  let i = 0;
  while (true) {
    const bubble = document.createElement('div');
    bubble.style.backgroundImage = `url("${images[i % images.length]}")`;
    bubble.style.position = 'absolute';
    bubble.style.left = 0;
    bubble.style.top = 0;
    bubble.style.width = `${bubbleSize}px`;
    bubble.style.height = `${bubbleSize}px`;
    bubble.style.margin = `-${bubbleSize / 2}px 50px -${bubbleSize / 2}px`;
    bubble.style.borderRadius = '50%';
    bubble.style.boxShadow = '0 15px 35px rgb(0,0,0, 0.1), 0 3px 10px rgb(0,0,0,0.07)';
    bubble.style.backgroundbubbleSize = 'cover';
    bubble.style.backgroundPosition = 'center';
    container.appendChild(bubble);

    if (prevBubble) {
      bubble.prevBubble = prevBubble;
      prevBubble.nextBubble = bubble;
    }
    prevBubble = bubble;
    i++;

    initBubble(bubble);
    bubble.style.transform = `translate(${bubble.x + bubble.dx}px, ${bubble.y + bubble.dy}px)`;

    if (bubble.y + SPACE_Y > height + bubbleSize) break;
  }

  const items = Array.from(container.children);
  items[0].prevBubble = prevBubble;
  prevBubble.nextBubble = items[0].prevBubble;

  // run
  let old_ts;
  function move(ts) {
    if (old_ts === undefined) old_ts = ts;
    if (ts - old_ts > 40) {
      old_ts = ts;

      items.map((bubble) => {
        if (Math.abs(bubble.dx) >= D) bubble.speedx *= -1;
        bubble.dx += bubble.speedx;

        if (Math.abs(bubble.dy) >= D) bubble.speedy *= -1;
        bubble.dy += bubble.speedy;

        bubble.y -= speed;
        if (bubble.y < minY) {
          initBubble(bubble);
        }

        bubble.style.transform = `translate(${bubble.x + bubble.dx}px, ${bubble.y + bubble.dy}px)`;
      });
    }
    requestAnimationFrame(move);
  }

  requestAnimationFrame(move);
}
