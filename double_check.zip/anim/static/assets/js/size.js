const BASE_WIDTH = 1800; // base screen
const BASE_ZOOM = 100; // 100%

function adjustZoomLevel() {
  const clientWidth = window.innerWidth; // user's screen
  const zoomLevel = (BASE_ZOOM / BASE_WIDTH) * clientWidth; // calculating zoom level

  if (window.chrome) {
    document.body.style.zoom = `${zoomLevel}%`;
  } else {
    document.body.style.transform = `scale(${zoomLevel / 100})`;
    document.body.style.transformOrigin = '50% 0';
  }
}

window.onload = function () {
  adjustZoomLevel(); // triggers when the page loads at first time
};

window.addEventListener('resize', (e) => {
  adjustZoomLevel(); // will trigger everytime the window got resized
});
