let intervalId = null
let intervalIdForPaymentProcessing = null
const cartItems = document.querySelectorAll('#payments-cart-slider .slider-item')
const paymentsCartWrapper = document.querySelector('.payments-cart-wrapper')
const paymentsPhone = document.querySelector('.payments-phone')
const cartItemsBox = document.querySelectorAll('#payments-cart-boxes-slider .slider-item')
const cartPrices = document.querySelectorAll('.payments-cart-footer-item')
const section2 = document.querySelector('#section1')
const awaitingTime = document.querySelector("#awaiting-time")

const restartSlider = () => {
  cartItems.forEach((item)=>{item.classList.remove('active')})
  cartItemsBox.forEach((item)=>{item.classList.remove('active')})
  cartPrices.forEach((item)=>{item.classList.remove('active')})

  cartItems[0].classList.add('active')
  cartItemsBox[0].classList.add('active')
  cartPrices[0].classList.add('active')
  
  cartItems[0].parentElement.style.transform = `translateX(0)`
  cartItemsBox[0].parentElement.style.transform = `translateX(0px)`
}

const playSlider = () => {
  let currentIndex = 0
  cartItems.forEach((item, index)=>{ if(item.classList.contains('active')) {
    currentIndex = index
  } })
  const current = document.querySelector('#payments-cart-slider .slider-item.active')
  const currentBox = document.querySelector('#payments-cart-boxes-slider .slider-item.active')
  const currentPrice = document.querySelector('.payments-cart-footer-item.active')

 
  let next = current.nextElementSibling ? current.nextElementSibling : cartItems[0]
  let nextBox = currentBox.nextElementSibling ? currentBox.nextElementSibling : cartItemsBox[0]
  let nextPrice = currentPrice.nextElementSibling ? currentPrice.nextElementSibling : cartPrices[0]

  const cartItemsWrapperPosition = current.nextElementSibling ? (currentIndex + 1) * current.offsetWidth : 0
  const cartItemsBoxWrapperPosition = currentBox.nextElementSibling ? (currentIndex + 1) * currentBox.offsetWidth : 0

  current.parentElement.style.transform = `translateX(-${cartItemsWrapperPosition}px)`
  currentBox.parentElement.style.transform = `translateX(-${cartItemsBoxWrapperPosition}px)`

  current.classList.remove('active')
  currentBox.classList.remove('active')
  currentPrice.classList.remove('active')

  next.classList.add('active')
  nextBox.classList.add('active')
  nextPrice.classList.add('active')
}


const setAnimations = () => {
  const animElements = document.querySelectorAll(".anim");

  animElements.forEach((item) => {
    const offsetFromTop = item.getBoundingClientRect().top;
    if (offsetFromTop < 800) {
      const anim = item.getAttribute("data-anim");
      const delay = item.getAttribute("data-anim-delay");
      const duration = item.getAttribute("data-anim-duration");
      item.classList.add(anim);
      if (duration) {
        item.style.animationDuration = `${duration}s`;
      }

      if (delay) {
        item.style.animationDelay = `${delay}s`;
      }
    }
  });
};


const loadFunctions = () => {
  setAnimations()
  document.querySelector('.body-overlay').style.display = 'none'

  if(intervalId) {
    clearInterval(intervalId)
  }
  
  if(intervalIdForPaymentProcessing) {
    clearInterval(intervalIdForPaymentProcessing)
  }
  if(intervalIdForPaymentProcessing) {
    clearInterval(intervalIdForPaymentProcessing)
  }

  const scrollFromTop = window.pageYOffset
  const windowHeight = window.innerHeight
  const windowWidth = window.innerWidth
  const bussinessPlan = document.querySelector('#section2')
  const bussinessPlanOffsetTop = bussinessPlan.offsetTop  - 160
  const section2FromTop = section2.getBoundingClientRect().top - 160
  const bussinessPlanFromTop = bussinessPlan.getBoundingClientRect().top
  const paymentsGraphic = document.querySelector('.payments-graphic')
  const paymentsGraphicOverlay = document.querySelector('.payments-graphic-content-overlay')
  const paymentsContent = document.querySelector('.payments-graphic-content')
  const paymentsCart = document.querySelector('.payments-cart')
  const paymentsCartBoxes = document.querySelector('.payments-cart-boxes')
  const paymentsCartBoxesItems = document.querySelectorAll('.payments-cart-box')
  const paymentsCartItems = document.querySelectorAll('.payments-cart-items')
  if(windowWidth > 1024 && bussinessPlanFromTop <= 100) {
    paymentsGraphic.style.position = "absolute"
    paymentsCartBoxes.style.position = "absolute"
    paymentsPhone.classList.remove('visible')
    paymentsPhone.style.top = `${bussinessPlanFromTop+10}px`

    paymentsGraphic.style.top = `${bussinessPlanOffsetTop + 200}px`
    paymentsCartBoxes.style.top = `${bussinessPlanOffsetTop + 160}px`
  } else {
    paymentsGraphic.style.position = "fixed"
    paymentsCartBoxes.style.position = "fixed"
    paymentsGraphic.style.top = `140px`
    paymentsCartBoxes.style.top = `260px`

  }

  if(windowWidth > 1024 && scrollFromTop >= 300) {
    paymentsGraphic.style.backgroundColor = "transparent"
    paymentsGraphic.style.boxShadow = "none"
    paymentsGraphicOverlay.style.background = "transparent"
    paymentsContent.style.transform = "translateX(100%) translateY(-100%)"
    paymentsCart.style.width = "calc(100% - 140px)"
    paymentsCart.style.boxShadow = "0 5px 25px -8px rgb(50 50 93 / 15%), 0 4px 4px -20px rgb(0 0 0 / 10%)"
    paymentsCartBoxes.classList.add('visible')
    paymentsCart.classList.add('extended')
    paymentsCartItems.forEach(item=> {item.style.width = "451px"; item.classList.add('no-anim')} )
    const width = paymentsCartItems.length * 451
    const boxWidth = paymentsCartBoxesItems.length * 210
    document.querySelector('.payments-cart-items-wrapper').style.width = `${width}px`
    document.querySelector('.payments-cart-boxes-wrapper').style.width = `${boxWidth}px`
    intervalId = setInterval(()=>{
      playSlider()
    }, 3000)
  } else {
    paymentsGraphic.style.backgroundColor = "#fff"
    paymentsGraphic.style.boxShadow = "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px rgba(0, 0, 0, 0.3) 0px 30px 60px -30px"
    paymentsGraphicOverlay.style.background = "rgba(255, 255, 255, 0.5)"
    paymentsContent.style.transform = "translateX(0) translateY(0)"
    paymentsCart.style.width = "256px"
    paymentsCart.style.boxShadow = "0 40px 81px -16px rgb(50 50 93 / 25%), 0 24px 48px -24px rgb(0 0 0 / 30%)"
    paymentsCartBoxes.classList.remove('visible')
    paymentsCart.classList.remove('extended')
    paymentsCartItems.forEach(item=> item.style.width = "224px")
    clearInterval(intervalId)
    restartSlider()
  }

  // Stop Slider when Scroll Reaches Section 2
  if(windowWidth > 1024 && section2FromTop <= -400) {
    intervalIdForPaymentProcessing = setInterval(()=>{
      awaitingTime.innerHTML = (parseFloat(awaitingTime.textContent) - 0.01 ).toFixed(2)
      console.log(parseInt(awaitingTime.textContent))
      if(parseInt(awaitingTime.textContent) === 0) {
        clearInterval(intervalIdForPaymentProcessing)      
      }
    }, 100)
    clearInterval(intervalId)
    paymentsCartBoxes.classList.remove('visible')
    paymentsPhone.classList.add('visible')
    paymentsCartWrapper.classList.add('swiped-up')


  } else {
    clearInterval(intervalIdForPaymentProcessing)
    paymentsPhone.classList.remove('visible')
    paymentsCartWrapper.classList.remove('swiped-up')
  }
}

document.addEventListener("load", loadFunctions());
window.addEventListener(
  "scroll",
  function () {
    loadFunctions();
  },
  false
);
